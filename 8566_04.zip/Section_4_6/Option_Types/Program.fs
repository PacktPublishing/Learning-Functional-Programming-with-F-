﻿// Learn more about F# at http://fsharp.org

open System
open System.Collections.Generic

type Foo = class end
let x : Foo = Unchecked.defaultof<Foo>

let users = Dictionary<int,string>()
users.Add(5,"onur")
let getUser id = 
    match users.TryGetValue id with
    | true, userName -> Some userName
    | _ -> None

let someUser = getUser 5

let printNumberOfChars (userName : string) =
    printf "%i" userName.Length



[<EntryPoint>]
let main argv =
    match someUser with 
    | Some userName -> printNumberOfChars userName
    | _ -> printf "%A" "No user found"
    0 // return an integer exit code
