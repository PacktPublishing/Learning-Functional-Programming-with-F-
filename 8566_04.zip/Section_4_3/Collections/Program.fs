﻿// Learn more about F# at http://fsharp.org

open System

let myList = [1;2;3]

let another = myList |> List.filter(fun x -> x = 1) |> List.map ( fun x -> x + 1)

let myArray = [|1;2;3|]

let z = myArray.[1]

let someAnotherList = [for x = 1 to 100 do yield! myArray] |> Set.ofList

let someSeq = {1..3} |> Seq.toList

let newList = 1 :: myList

match myList with
| [] -> // do something
| head :: tail -> 

[<EntryPoint>]
let main argv =
    printfn "Hello World from F#!"
    0 // return an integer exit code
