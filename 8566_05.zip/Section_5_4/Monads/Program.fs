﻿// Learn more about F# at http://fsharp.org

open System
type Int32 with
    static member ParseAsOption str =
        match Int32.TryParse str with
        | false,_ -> None
        | true,x  -> Some x

let (>>=) m f = Option.bind f m


let readInput() =
    Console.ReadLine() |> Int32.ParseAsOption

let retn x = Some x


let addition =
    readInput() >>= (fun x ->
    readInput() >>= (fun y ->
        let sum = x + y
        retn sum
    ))

printfn "addition: %A" addition


//let x = readInput()
// readInput() >>= (fun x ->

type MaybeBuilder() =
    member o.Bind (m, f) = Option.bind f m
    member o.Return x = Some x
 

let maybe = MaybeBuilder()


let addition2 = maybe {
    let! x = readInput ()
    let! y = readInput ()
    let  sum = x + y
    return sum
}
let addition3 = maybe {
    let! x = addition2
    printfn "inside addition3"
    let! y = readInput ()
    let  sum = x + y
    return sum
}
printfn "addition: %A" <| addition3




let map f opt = maybe {
    let! x = opt  
    return f x    
}

let apply fo xo = maybe {
    let! f = fo  
    let! x = xo  
    return f x   
}
let f1 x = Some (x + 1)

let f2 x = Some (x * 2)

 //let c = f1 >> f2

let (>=>) f g x = (f x) >>= g

let c x =  (f1 >=> f2) x

printfn "kleisli %A" <| c 5 

[<EntryPoint>]
let main argv = 0

