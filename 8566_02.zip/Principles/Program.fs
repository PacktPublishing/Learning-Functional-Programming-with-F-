﻿// Learn more about F# at http://fsharp.org

open System

let  add x y = x + y

let inc = add 1

let double x =  x * 2

[<EntryPoint>]
let main argv =
    let mutable x = 1
    x <- 6
    let l = [1;2;3]

    let incDouble = (List.map inc) >> (List.map double)
    let newList = l |> incDouble
    printf "%A" newList
 



    0 // return an integer exit code
