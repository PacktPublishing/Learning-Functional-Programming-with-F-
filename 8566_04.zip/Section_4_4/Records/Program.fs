﻿// Learn more about F# at http://fsharp.org

open System

[<Struct>]
type Person = { mutable FirstName : string ; LastName : string}

let mutable john = {FirstName= "John"; LastName = "Connor"}

john.FirstName <- "John2"

let sarah = {john with FirstName = "Sarah"}

let {FirstName = name} = sarah 

let alterFirstName person firstName =  { person with FirstName = firstName}


[<EntryPoint>]
let main argv =
    let newJohn = alterFirstName john "John"
    printfn "%A" (newJohn = john)
    0 // return an integer exit code
