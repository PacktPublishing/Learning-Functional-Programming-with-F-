﻿// Learn more about F# at http://fsharp.org

open System
type Int32 with
    static member ParseAsOption str =
        match Int32.TryParse str with
        | false,_ -> None
        | true,x  -> Some x

let bindOption f opt =
    match opt with
    | None   -> None
    | Some x -> f x

let joinOption opt =
    match opt with
    | None          -> None
    | Some innerOpt -> innerOpt

let bindOption2 f opt = joinOption (Option.map f opt)



let input1 = Some "abcde" |> bindOption  Int32.ParseAsOption  // None

printfn "input1: %A" input1
let input2 = Some "100"   |> bindOption2 Int32.ParseAsOption  // Some 100

printfn "input2: %A" input2
let input3 = Some "200"   |> Option.map  Int32.ParseAsOption  // Some (Some 200)
printfn "input3: %A" input3


let (>>=) m f = Option.bind f m

let add x y = x + y

let liftedAdd = Some add

let apply f m =
    match f, m with
    | Some f, Some m -> Some(f m)
    | _ -> None
 
let (<*>) = apply
let input4 = 
    liftedAdd <*> 
        (Some "100" >>= Int32.ParseAsOption) <*> 
        (Some "200" >>= Int32.ParseAsOption) 
printfn "input4: %A" input4

let input5 = 
    liftedAdd <*> 
        (Some "100" >>= Int32.ParseAsOption) <*> 
        (Some "ABC" >>= Int32.ParseAsOption) 
printfn "input5: %A" input5

[<EntryPoint>]
let main argv = 0

