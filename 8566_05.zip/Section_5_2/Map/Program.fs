﻿

open System

module Option =
    let map f  = function
        | Some x -> f x |> Some
        | _ -> None

    let ret = Some

    let apply f x =
        match f, x with 
        | Some f, Some x -> f x |> Some
        | _ -> None

let inc x = x + 1
let optInc = Option.map inc

let elevatedTwo = Option.ret 2
printfn "%A"  ( optInc elevatedTwo )

let add x y = x + y

let elevatedThree = Option.ret 3
let elevatedAdd = Option.ret add


let apply1 = elevatedTwo |> Option.apply elevatedAdd 
let apply2 = elevatedThree |> Option.apply apply1
printfn "%A" <| apply2

let (<*>) = Option.apply

let res =  (Option.ret add ) <*> elevatedTwo <*> elevatedThree
printfn "%A" res
        
let res1 =  (Option.ret add ) <*> None <*> elevatedThree
printfn "%A" res1

[<EntryPoint>]
let main argv = 0 
