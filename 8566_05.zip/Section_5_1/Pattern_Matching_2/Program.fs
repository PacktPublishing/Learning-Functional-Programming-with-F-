﻿// Learn more about F# at http://fsharp.org

open System


let (|Fizz|Buzz|FizzBuzz|Other|) = function
    | 0, 0 -> FizzBuzz
    | 0, _ -> Fizz 
    | _, 0 -> Buzz 
    | _ -> Other
    
   
let (|Fizz|_|) = function | 0, _ -> Some Fizz | _ -> None

let (|Buzz|_|) = function | _, 0 -> Some Buzz | _ -> None

for c in [1..15] do
    match c % 3, c % 5 with
    | Fizz & Buzz-> printfn "FizzBuzz" 
    | Fizz -> printfn "Fizz"
    | Buzz -> printfn "Buzz"
    | _  when c = 10 -> printfn "%i" 10
    | _  -> printfn "%i" c

[<EntryPoint>]
let main argv = 0
