﻿// Learn more about F# at http://fsharp.org

open System
let x = 3
let text = 
    match x with
    | 0 -> "Zero"
    | 1 -> "One"
    | 2 -> "Two"
    | 3 -> "Three"
    | _ -> "Smaller than Zero or greater than Three"

printfn "%A" text

[<EntryPoint>]
let main argv = 0