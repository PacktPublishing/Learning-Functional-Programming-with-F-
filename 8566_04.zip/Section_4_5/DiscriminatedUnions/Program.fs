﻿// Learn more about F# at http://fsharp.org

open System

type Color = White | Black 

type PieceKind = King | Queen | Rook | Knight | Bishop | Pawn

// type Piece = { Color : Color; Kind : PieceKind }

type Piece = MyPiece of Color : Color * Kind : PieceKind

type 'a MyList = Empty | ListNode of 'a * 'a MyList


let someList = ListNode(1, ListNode(2, Empty))

let getCount list = 
    let rec innerCount list count = 
        match list with
        | Empty -> count
        | ListNode(_,subList) -> innerCount subList (count + 1)
    
    innerCount list 0
        









[<EntryPoint>]
let main argv =
    let piece = MyPiece(  White,  King)
    let MyPiece(Color = c ) = piece
    printfn "%A" <| getCount someList
    0 // return an integer exit code
