﻿open System.Net
open System.Threading.Tasks

let urlList = [ "Microsoft", "http://www.microsoft.com/"
                "Google", "http://www.google.com/"
                "Apple", "http://www.apple.com"
              ]

let fetchAsync(name, url:string) =
    async {
        try
            printfn "Thread id %i for uri %s" 
                System.Threading.Thread.CurrentThread.ManagedThreadId url
            let uri =  System.Uri(url)

            let webClient = new WebClient()
            let! html = webClient.DownloadDataTaskAsync(uri) |> Async.AwaitTask
            printfn "Thread id %i for uri %s" 
                System.Threading.Thread.CurrentThread.ManagedThreadId url
            printfn "Read %d characters for %s" html.Length name
        with
            | ex -> printfn "%s" (ex.Message);
    }

urlList
|> Seq.map fetchAsync
|> Async.Parallel
|> Async.RunSynchronously
|> ignore

