﻿// Learn more about F# at http://fsharp.org

open System

type Line  = { X1: int ; X2: int; Y1: int ; Y2 : int}

let line = { X1 = 1; X2 = 2; Y1 = 3; Y2 = 4}

let {X1 = x} = line

printfn "%A" x

let {Y1 = y; X2 = x2} = line

printfn "%A" y

type Circle  = Circle of r : int

let circle = Circle 5

let (Circle r) = circle
printfn "%A" r

type Shape = Circle of Circle | Line2 of Line

let shape = Line2 line

match shape with
| Circle r -> printfn "%A" r
| Line2 {X1 = x;}-> printfn "This is a line with X1 = %A" x


let printCoordinates {X1 = x1; X2 = x2; Y1 = y1; Y2 = y2} =
    printfn "%A, %A, %A, %A" x1 x2 y1 y2

printCoordinates line



[<EntryPoint>]
let main argv = 0
   