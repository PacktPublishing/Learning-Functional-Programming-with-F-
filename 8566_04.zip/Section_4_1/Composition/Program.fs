﻿// Learn more about F# at http://fsharp.org

open System


let cons a b = List.Cons(a,b)

let rec reduce f x  = 
    function
    | [] -> x
    | head :: tail -> f head <| (reduce f x) tail



let add x y = x + y

let multiply x y = x * y
let sum = reduce add 0
let mul = reduce multiply 1


let anytrue = reduce (||) false

let alltrue = reduce (&&) true

let append a b = reduce cons b a

let doubleandcons num list = cons (2 * num) list

let doubleall = reduce doubleandcons []

let fandcons f  = f >> cons

let double n = 2 * n

let doubleandcons2 = fandcons double

let map f = reduce (f >> cons) []
let doubleall2 = map double


[<EntryPoint>]
let main argv =

    printfn "%A" <| doubleall2 [1;2;3]
    0 // return an integer exit code
