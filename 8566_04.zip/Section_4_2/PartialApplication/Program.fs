﻿// Learn more about F# at http://fsharp.org

open System

let runDBQuery (connString:string) (query:string) = "dummy result"

let runOracleQuery = runDBQuery "myOracleConn"





[<EntryPoint>]
let main argv =
    printfn "Hello World from F#!"
    0 // return an integer exit code
